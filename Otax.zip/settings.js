
const settings = {
  OWNER_URL: "http://t.me/Ghazzzzzi", //ganti Otapengenkawin dengan username tele lu
  BOT_USERNAME: "@Polisi62_bot"
  // isi dengan bot lu jika mau fitur kendalikan bot jarak jauh
};
//ganti bagian dalam '...' saja
module.exports = settings;